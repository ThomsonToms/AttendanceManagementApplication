/*
 * Filename:    StudentMenuPanel.java
 * Package:     frontEnd
 * Project:     Attendance Management System
 * Author:      Jacob Bianco, Comlan Acolitse, and Thomson Toms
 * Section:     IST 311
 * Assignment:  Sprint 3
 * Description: This class is the student menu panel
 * Date Created: 11/1/22
 * Date modified: 11/1/22
 * */
package frontEnd;

import javax.swing.*;
import java.awt.*;       
 

public class StudentMenuPanel extends JPanel
{
	
		//creates some components for the panel
		JLabel lblOne;
		JButton cmdViewS, cmdLogOut;
		JPanel topPanel, middlePanel, button1Panel, button2Panel;
		
		//creates two constants for the panel
		final int CWIDTH = 300;
		final int CHEIGHT = 100;
	
		 //default constructor
		public StudentMenuPanel()
		{
			
			//creates a label and sets its size and font
			lblOne = new JLabel ("Welcome to the Attendance Application");
			lblOne.setPreferredSize(new Dimension(CWIDTH+175,CHEIGHT));
			lblOne.setFont(new Font("Serif", Font.BOLD, 28));
			
			//creates a button and sets its size and font
			cmdViewS = new JButton ("View Info ");
			cmdViewS.setPreferredSize(new Dimension(CWIDTH,CHEIGHT));
			cmdViewS.setFont(new Font("Serif", Font.BOLD, 18));
			
			//creates a button for logging out 
			cmdLogOut = new JButton ("Log Out");
			cmdLogOut.setPreferredSize(new Dimension(CWIDTH,CHEIGHT));
			cmdLogOut.setFont(new Font("Serif", Font.BOLD, 18));
			
			//creates a top panel that contains the label
			topPanel = new JPanel(new FlowLayout());
			topPanel.add(lblOne);
			topPanel.setBackground(Color.WHITE);
			
			//creates a button panel which contains the view info button
			button1Panel = new JPanel();
			button1Panel.add(cmdViewS);
			button1Panel.setBackground(Color.WHITE);
		
			//creates a button panel which contains the log out button
			button2Panel = new JPanel();
			button2Panel.add(cmdLogOut);
			button2Panel.setBackground(Color.WHITE);
			
			//creates a middle panel which contains the button panel at it's center
			middlePanel = new JPanel(new GridLayout(3,1));
			middlePanel.add(new JLabel());
			middlePanel.add(button1Panel);
			middlePanel.add(button2Panel);
			middlePanel.setBackground(Color.WHITE);
			
			//sets the layout of this panel and adds the inner panels to it
			setLayout(new BorderLayout());
			add(topPanel, BorderLayout.NORTH);
			add(middlePanel, BorderLayout.CENTER);
			setBackground(Color.WHITE);
			   
		}
		
	}



