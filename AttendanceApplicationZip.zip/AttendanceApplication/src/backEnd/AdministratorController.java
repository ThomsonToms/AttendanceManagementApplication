package backEnd;
/*
 * Filename:    AdministratorController.java
 * Package:     No package
 * Project:     Attendance Management System
 * Author:      Jacob Bianco, Comlan Acolitse, and Thomson Toms
 * Section:     IST 311
 * Assignment:  Sprint 1
 * Description: This is the Administrator Controller class and it keeps the view and model separate.
 * Date Created: 9/3/22
 * Date modified:10/6/22
 *
 */
import java.sql.SQLException;
import java.util.ArrayList;


public class AdministratorController {
	
	private Administrator model;
    private AdministratorView view;
    private AdministratorActions data;

    
    //Overloaded Controller
    public AdministratorController(Administrator model, AdministratorView view, AdministratorActions data){
        this.model = model;
        this.view = view; 
        this.data = data;
    }

    public Administrator getModel() {
		return model;
	}


	public void setModel(Administrator model) {
		this.model = model;
	}


	public AdministratorView getView() {
		return view;
	}


	public void setView(AdministratorView view) {
		this.view = view;
	}


	public AdministratorActions getData() {
		return data;
	}


	public void setData(AdministratorActions data) {
		this.data = data;
	}


	//sets a user's first name
    public void setAdmininistratorfName(String fName){model.setfName(fName);}
    
    
    //sets a user's last name
    public void setAdmininistratorlName(String lName){model.setlName(lName);}
    
    
    //returns a user's first name as a string
    public String getAdmininistratorfName(){return model.getfName();}
    
    
    //returns a user's last name as a string
    public String getAdmininistratorlName(){return model.getlName();}

    
    //sets a user's gender
    public void setAdmininistratorGender(String userGender){model.setGender(userGender);}

    
    //returns a user's gender as a string
    public String getAdmininistratorGender(){return model.getGender();}

    
    //sets a PIN for a user
    public void setAdmininistratorPIN(String PIN){model.setPIN(PIN);}
    
    //returns the user's PIN as a string
    public String getAdmininistratorPIN(){return model.getPIN();}
	
    
    //This method calls to set the size of the class from the Administrator class
    public void administratorSetClassID(int classID){model.setClassID(classID);}

    
    //This method calls to return the class size from the Administrator class
    public int administratorGetClassID(){return model.getClassID();}

    
    //This method calls to add a student from the Administrator class
    public void administratorAddStudentToClass(Student s) {model.addStudentToClass(s);}

    
    //This method calls to mark attendance from the Administrator class
    public ArrayList<Student> administratorGetClassList(){return model.getClassList();}
    
    
    //This method inputs the corresponding class of students into the admins class
    public void administratorGetStudentsInClass() {data.getStudentsInClass(model);}
    
    
    //this method outputs the menu for an admin
    public void displayAdministratorMenu() {try {view.displayMenu(model, data);} 
    catch (SQLException e) {e.printStackTrace();}
    }
    
    
    //This method calls to print and return administrator information from the Administrator class
    public void updateAdministratorView(){view.printAdministratorInfo(model);}

    
    //this method updates an administrator's class info
    public void updateAdministratorClassInfo() {view.printAdministratorClassInfo(model);}
    
    
    //This methods calls to exit the program and display an output message for the admin
    public void administratorExitProgram() {view.exitProgram(model);}
}
