/*
 * Filename:    AdminAddStudentPanel.java
 * Package:     frontEnd
 * Project:     Attendance Management System
 * Author:      Jacob Bianco, Comlan Acolitse, and Thomson Toms
 * Section:     IST 311
 * Assignment:  Sprint 3
 * Description: This class contains the panel that is displayed for the add student screen
 * Date Created: 11/1/22
 * Date modified: 11/1/22
 *
 */
package frontEnd;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import backEnd.AdministratorController;

public class AdminAddStudentPanel extends JPanel{
	//components used in class
	JButton bButton, hButton, sButton;
	JRadioButton femaleButton, maleButton;
	JTextField userText, userText2, pinText;
	
	//default constructor which is empty
	AdminAddStudentPanel(){}
	
	//overloaded constructor
	AdminAddStudentPanel(AdministratorController aController){
		
		//sets the layout to border layout
		setLayout(new BorderLayout());
	
		//sets information about components of the class
		JLabel lblHeader = new JLabel("    Register a Student");
	    lblHeader.setPreferredSize(new Dimension(275,100));
		lblHeader.setFont(new Font("Serif", Font.BOLD, 28));
		lblHeader.setBackground(Color.WHITE);
		
		JPanel headerPanel = new JPanel(new FlowLayout());
		headerPanel.setPreferredSize(new Dimension(475,100));
		headerPanel.setFont(new Font("Serif", Font.BOLD, 28));
		headerPanel.setBackground(Color.WHITE);
		headerPanel.add(lblHeader);
		
		JPanel topGrid = new JPanel(new FlowLayout());
		topGrid.setPreferredSize(new Dimension(500,125));
		topGrid.setBackground(Color.WHITE);
		
		JLabel fnameLabel = new JLabel("First name:");
		fnameLabel.setPreferredSize(new Dimension(150,50));
		fnameLabel.setFont(new Font("Serif", Font.BOLD, 25));
		topGrid.add(fnameLabel);
		
		userText = new JTextField(10);
		userText.setDocument(new LengthRestrictedDocument(15));
		userText.setPreferredSize(new Dimension(100,50));
		userText.setFont(new Font("Serif", Font.BOLD, 25));
		topGrid.add(userText);
		
		JPanel midGrid = new JPanel(new FlowLayout());
		midGrid.setPreferredSize(new Dimension(500,125));
		midGrid.setBackground(Color.WHITE);
		
		JPanel midGrid2 = new JPanel(new FlowLayout());
		midGrid2.setPreferredSize(new Dimension(500,125));
		midGrid2.setBackground(Color.WHITE);
		
		JLabel lnameLabel = new JLabel("Last name:");
		lnameLabel.setPreferredSize(new Dimension(150,50));
		lnameLabel.setFont(new Font("Serif", Font.BOLD, 25));
		midGrid2.add(lnameLabel);
		
		userText2 = new JTextField(10);
		userText2.setDocument(new LengthRestrictedDocument(15));
		userText2.setPreferredSize(new Dimension(100,50));
		userText2.setFont(new Font("Serif", Font.BOLD, 25));
		midGrid2.add(userText2);
				
		JLabel genderLabel = new JLabel("Gender:");
		genderLabel.setPreferredSize(new Dimension(165,50));
		genderLabel.setFont(new Font("Serif", Font.BOLD, 25));;
		midGrid.add(genderLabel);
		
		maleButton = new JRadioButton("Male"); 
		maleButton.setBackground(Color.WHITE);
		femaleButton = new JRadioButton("Female"); 
		femaleButton.setBackground(Color.WHITE);
		
		ButtonGroup bGroup = new ButtonGroup();
        bGroup.add(maleButton);
        bGroup.add(femaleButton);
        
        JPanel p1 = new JPanel();
        p1.add(maleButton);
        p1.setBackground(Color.WHITE);
        
        JPanel p2 = new JPanel();
        p2.add(femaleButton);
        p2.setBackground(Color.WHITE);
        
        JPanel radioPanel = new JPanel();
        radioPanel.setLayout(new FlowLayout());
        radioPanel.add(p1);
        radioPanel.add(p2);
		midGrid.add(radioPanel);
        
		JPanel bottomGrid = new JPanel(new FlowLayout());
		bottomGrid.setPreferredSize(new Dimension(500,125));
		bottomGrid.setBackground(Color.WHITE);
		
        JLabel pinLabel = new JLabel("PIN:");
        pinLabel.setPreferredSize(new Dimension(125,50));
        pinLabel.setFont(new Font("Serif", Font.BOLD, 25));;
		pinLabel.setBackground(Color.WHITE);
		bottomGrid.add(pinLabel);
		
		pinText = new JTextField(5);
		pinText.setDocument(new LengthRestrictedDocument(5));
		pinText.setPreferredSize(new Dimension(50,50));
		pinText.setFont(new Font("Serif", Font.BOLD, 25));
		bottomGrid.add(pinText);
		
		JPanel bottomGrid2 = new JPanel(new FlowLayout());
		bottomGrid2.setPreferredSize(new Dimension(500,125));
		bottomGrid2.setBackground(Color.WHITE);
		
		sButton = new JButton("Submit ");
		sButton.setPreferredSize(new Dimension(100,50));
		sButton.setFont(new Font("Serif", Font.BOLD, 18));
		bottomGrid2.add(sButton);
		
		
		JPanel centerPanel = new JPanel(new GridLayout(5,1));
		centerPanel.setPreferredSize(new Dimension (600, 400));
		centerPanel.add(topGrid);
		centerPanel.add(midGrid2);
		centerPanel.add(midGrid);
		centerPanel.add(bottomGrid);
		centerPanel.add(bottomGrid2);
		
		
		JPanel bottomPanel = new JPanel (new FlowLayout());
		bottomPanel.setBackground(Color.white);
		
		bButton = new JButton("Back");
		bButton.setPreferredSize(new Dimension(250,50));
		bButton.setFont(new Font("Serif", Font.BOLD, 32));
		bottomPanel.add(bButton);
		
		hButton = new JButton("Home");
		hButton.setPreferredSize(new Dimension(250,50));
		hButton.setFont(new Font("Serif", Font.BOLD, 32));
		bottomPanel.add(hButton); 
		
		//adds each panel to a specific spot on the screen
		add(centerPanel, BorderLayout.CENTER);
		add(headerPanel, BorderLayout.NORTH);
		add(bottomPanel, BorderLayout.SOUTH);
	}
}
