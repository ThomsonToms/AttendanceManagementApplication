/*
 * Filename:    DatabaseActions.java
 * Package:     No package
 * Project:     Attendance Management System
 * Author:      Jacob Bianco, Comlan Acolitse, and Thomson Toms
 * Section:     IST 311
 * Assignment:  Sprint 2
 * Description: This class contains all of the database access functions for the project
 * Date Created: 9/28/22
 * Date modified: 10/6/22
 */
import java.sql.*;
import java.util.Scanner;

public class StudentActions {
	//the below statements initialize all of the variables which will be using in the class
static final String DATABASE_URL = "jdbc:ucanaccess://C:/Users/jacob/eclipse-workspace/HR/AADatabase.accdb";
private Connection conn = null;
private Statement stmt = null;
private ResultSet rset = null; 


//default constructor for the database creates a connection to the database
public StudentActions(){
try {
	conn = DriverManager.getConnection(DATABASE_URL);
}

catch (SQLException sqlError) {sqlError.printStackTrace();}
}

//retrieves the student's data by taking the PIN from the login as a parameter and return the corresponding student info in a student object
public Student getStudentData(String PIN) throws SQLException{
	
		Student s = new Student();
		String qStr = "Select * from Student where StudentPIN = '" + PIN + "'";  //query
		stmt = conn.createStatement(); //creates statement
		rset = stmt.executeQuery(qStr); //executes query stored in the string
   
		while(rset.next()) {   // processes the row
			s = new Student(rset.getString("FirstName"), rset.getString("LastName"), rset.getString("Gender"), 
    		rset.getString("StudentPIN"), rset.getInt("DaysMissed"), rset.getInt("DaysAttended")); //inputs the students info into a student object
    }
		return s; //returns the student object
 }


//close the connection to the database
public void closeConnection() {
	try {
		conn.close(); //tries to close the connection to the database
	} catch (SQLException e) {
		e.printStackTrace(); //prints the stack trace if an error occurs
	}
}


}

