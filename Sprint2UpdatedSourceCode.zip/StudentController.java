import java.sql.SQLException;

/*
 * Filename:    StudentController.java
 * Package:     No package
 * Project:     Attendance Management System
 * Author:      Jacob Bianco, Comlan Acolitse, and Thomson Toms
 * Section:     IST 311
 * Assignment:  Sprint 1
 * Description: Separates the view and model of a Student
 * Date Created: 9/3/22
 * Date modified:10/6/22
 *
 */
public class StudentController {
    private Student model;
    private StudentView view;
    private StudentActions data;

    
    //overloaded controller which takes model and view as arguments
    StudentController(Student model, StudentView view, StudentActions data){
        this.model = model;
        this.view = view;
        this.data = data;
    }

    
    //increments the student's days missed with an integer argument
    public void setStudentDaysMissed(int daysMissed){model.setDaysMissed(daysMissed);}

    
    //returns the student's days missed as an integer
    public int getStudentDaysMissed(){return model.getDaysMissed();}

    
    //increments the student's days attended with an integer argument
    public void setStudentDaysAttended(int daysAttended){model.setDaysAttended(daysAttended);}

    
    //returns the student's days attended as an integer
    public int getStudentDaysAttended(){return model.getDaysAttended();}

    
    //calculates the days which have passed in the school year
    public void setStudentDaysPassed(int daysMissed, int daysAttended){model.setDaysPassed(daysMissed, daysAttended);}

    
    //returns the school days passed as an integer
    public int getStudentDaysPassed(){return model.getDaysPassed();}

    
    //prints the student's attendance
    public void updateStudentView(){view.printStudentAttendance(model);}
    
    
    public void studentCloseConnection() {data.closeConnection();}
    
    
    public void displayStudentMenu() {try {view.displayMenu(data, model);}
    catch (SQLException e) {e.printStackTrace();}
    }
    
    
    //prints an exit message and exits the program
    public void studentExitProgram() {view.exitProgram(model);}
}
