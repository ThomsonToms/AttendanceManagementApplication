package backEnd;

/*
 * Filename:    Student.java
 * Package:     No package
 * Project:     Attendance Management System
 * Author:      Jacob Bianco, Comlan Acolitse, and Thomson Toms
 * Section:     IST 311
 * Assignment:  Sprint 1
 * Description: The Student class inherits the methods from the User class and implements methods for
 *              a student to use.
 * Date Created: 9/3/22
 * Date modified:9/15/22
 *
 */
public class Student{
    private int daysMissed; //days that the student missed
    private int daysAttended; //days that the student attended
    private int daysPassed; //days of the school year that passed
    private String fName, lName, userGender, PIN; //basic variables for a user

    
   //default constructor
    public Student(){
    	fName = lName = "";
        userGender = "";
        PIN = "null";
        daysMissed = 0;
        daysAttended = 0;
        daysPassed = 0;
    }

    //Overloaded constructor
    public Student(String fName, String lName, String userGender, String PIN, int daysMissed, int daysAttended){
    	this.fName = fName;//sets the first name of the user
        this.lName = lName;//sets the last name of the user
        this.userGender = userGender;//sets the gender of the user
        this.PIN = PIN;//sets a user's PIN
        this.daysMissed = daysMissed; //sets days missed
        this.daysAttended = daysAttended; //sets days attended
    }
    //sets a user's first name
    public void setfName(String fName){this.fName = fName;}
    
    
    //sets a user's last name
    public void setlName(String lName){this.lName = lName;}
    
    
    //returns a user's first name as a string
    public String getfName(){return fName;}
    
    
    //returns a user's last name as a string
    public String getlName(){return lName;}

    
    //sets a user's gender
    public void setGender(String userGender){this.userGender = userGender;}

    
    //returns a user's gender as a string
    public String getGender(){return userGender;}

    
    //sets a PIN for a user
    public void setPIN(String PIN){
        this.PIN = PIN;
    }
    
    //returns the user's PIN as a string
    public String getPIN(){return PIN;}


    //increments the days missed and adds it to the previous value
    public void setDaysMissed(int daysMissed){this.daysMissed += daysMissed;}

    // This method returns the days that the student missed
    public int getDaysMissed(){return daysMissed;}

    //increments the days attended and adds it to the previous value, note that
    //this method is here so the admin can access. This cannot be used by the student
    public void setDaysAttended(int daysAttended){this.daysAttended += daysAttended;}

    //This method returns/prints the days the student attended or were marked by admin
    public int getDaysAttended(){return daysAttended;}

    // This method is here so the admin can access. This cannot be used by the student
    public void setDaysPassed(int daysMissed, int daysAttended){daysPassed = (daysMissed + daysAttended);}

    //returns the days passed as an integer
    public int getDaysPassed(){return daysPassed;}

    
}
