/*
 * Filename:    Administrator.java
 * Package:     No package
 * Project:     Attendance Management System
 * Author:      Jacob Bianco, Comlan Acolitse, and Thomson Toms
 * Section:     IST 311
 * Assignment:  Sprint 1
 * Description: The Administrator class inherits the methods from the User class and implements methods for
 *              an admin to use.
 * Date Created: 9/3/22
 * Date modified: 10/6/22
 *
 */
import java.util.ArrayList;//imports the arraylist to be used to store info about class of students


public class Administrator extends User {
    private ArrayList<Student> sClass = new ArrayList<Student>();//creates an arraylist of students
    private int classID; // stores the admin's classID number
    

    //default constructor for an administrator
    Administrator() {
    super();
    classID = 0;
    }

    
    //overloaded constructor which takes an administrator's name, gender, and class size as arguments
    Administrator(String fName, String lName, String userGender, String PIN, int classID) {
        super(fName, lName, userGender, PIN); //calls the overloaded constructor of user
        this.classID = classID;
    }
    
    
    //sets the classID of the admin
    public void setClassID(int classID){this.classID = classID;}

    
    //returns the size of a class as an integer
    public int getClassID(){return classID;}

    
    //enables the administrator to add a student to the class
    public void addStudentToClass(Student s) {sClass.add(s);}
   
    
    //returns the admin's class list as an arraylist
    public ArrayList<Student> getClassList(){return sClass;}

 
}
