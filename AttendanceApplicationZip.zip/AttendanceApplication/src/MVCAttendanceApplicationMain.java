import java.sql.SQLException;
import frontEnd.MainFrame;

/*
 * Filename:    MVCAttendanceApplicationMain.java
 * Package:     No package
 * Project:     Attendance Management System
 * Author:      Jacob Bianco, Comlan Acolitse, and Thomson Toms
 * Section:     IST 311
 * Assignment:  Sprint 2
 * Description: Main method contains a working version of the app which connects to a database and outputs to the console
 * Date Created: 9/3/22
 * Date modified:10/6/22
 *
 */
public class MVCAttendanceApplicationMain {
		
    //Main method
    public static void main(String args[]) throws SQLException{
    	MainFrame mainFrame = new MainFrame();
}
}