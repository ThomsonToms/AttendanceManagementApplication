package backEnd;
/*
 * Filename:    DatabaseActions.java
 * Package:     No package
 * Project:     Attendance Management System
 * Author:      Jacob Bianco, Comlan Acolitse, and Thomson Toms
 * Section:     IST 311
 * Assignment:  Sprint 2
 * Description: This class contains all of the database access functions for the project
 * Date Created: 9/28/22
 * Date modified: 10/6/22
 */
import java.sql.*;
import java.util.Scanner;

import javax.swing.JOptionPane;

public class AdministratorActions {
	//the below statements initialize all of the variables which will be using in the class
static final String DATABASE_URL = "jdbc:ucanaccess://C:/Users/jacob/eclipse-workspace/HR/AADatabase.accdb";
private Connection conn = null;
private Statement stmt = null;
private ResultSet rset = null; 
private PreparedStatement insertNewStudentInStudent = null;
private PreparedStatement insertNewStudentInEnrollment = null;
private PreparedStatement deleteStudentInStudent = null;
private PreparedStatement deleteStudentInEnrollment = null;


//default constructor for the database creates a connection to the database
public AdministratorActions(){
try {
	conn = DriverManager.getConnection(DATABASE_URL);
}

catch (SQLException sqlError) {sqlError.printStackTrace();}
}


//allows an admin to take attendance for their class
public void markClassAttendance(Administrator a, boolean present, int i) {
		String qStr = "";
	
			  try {
				 
	            if (present) { //if the student is in class, do this
	            	
	            	int attended = a.getClassList().get(i).getDaysAttended();
	            	attended ++;
	            	qStr = "UPDATE Student SET DaysAttended ='" + attended + "'WHERE StudentPIN =  '" 
	            	+ a.getClassList().get(i).getPIN() + "'";
	            }
	            else { //if the student is not in class, do this
	            	
	            	int missed = a.getClassList().get(i).getDaysMissed();
	            	missed ++;
	            	qStr = "UPDATE Student SET DaysMissed ='" + missed + "'WHERE StudentPIN =  '"
	            	+ a.getClassList().get(i).getPIN() + "'";
	            }
	          
	            stmt = conn.createStatement();
			    stmt.executeUpdate(qStr); //executes query stored in the string
			 
		}
     
			catch(SQLException error) {
				error.printStackTrace(); //prints error if it occurs in the database
				}
		}

		
//takes a student's PIN as a parameter and removes that student from a class
public int removeStudent(String PIN){
		int result = 0; 

		try{ 
			deleteStudentInStudent = conn.prepareStatement("DELETE FROM Student WHERE StudentPIN = ?"); //SQL statement to delete student
			deleteStudentInEnrollment = conn.prepareStatement("DELETE FROM Enrollment WHERE StudentPIN = ?"); //SQL statement to delete student 
		
			deleteStudentInStudent.setString(1, PIN); //sets the question mark equal to the student's userPIN
			deleteStudentInEnrollment.setString(1, PIN); //sets the question mark equal to the student's userPIN
		
			deleteStudentInStudent.executeUpdate(); //executes the update
			result = deleteStudentInEnrollment.executeUpdate(); //executes the update
		
			if (result == 1)
			{
				JOptionPane.showMessageDialog(null, "The student has been removed from the class."); // outputs that the Student has been deleted from the table
			}
			else {
				JOptionPane.showMessageDialog(null, "The student's PIN has not been found. Try again."); // outputs that the Student has been deleted from the table
			}
	
}
			catch(SQLException error) {
				error.printStackTrace(); //prints error if it occurs in the database
		}
			return result;
}


//adds a student into a class; parameter for the function is a student object, and classID for the class also is retrieved from the user 
public int addStudent(Student s, int classID){
		int result = 0;
		int check = 0;
				
		try{
			insertNewStudentInStudent = conn.prepareStatement("INSERT INTO Student (FirstName, LastName, Gender, StudentPIN, DaysMissed, DaysAttended) "
					+ "VALUES (?, ?, ?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
			insertNewStudentInStudent.setString(1,s.getfName());
			insertNewStudentInStudent.setString(2,s.getlName());
			insertNewStudentInStudent.setString(3,s.getGender());
			insertNewStudentInStudent.setString(4,s.getPIN());
			insertNewStudentInStudent.setInt(5, s.getDaysMissed());
			insertNewStudentInStudent.setInt(6, s.getDaysAttended());
			
			result = insertNewStudentInStudent.executeUpdate(); //inserts the new student info into the student table
			
			if (result == 1)  check++;
		}
		catch(SQLException error) {
				 error.printStackTrace(); //outputs the stack trace if error occurs
				}
		result = 0; //sets result back to 0
		try {
			insertNewStudentInEnrollment = conn.prepareStatement("INSERT INTO Enrollment (StudentPIN, ClassID, EnrollmentYear) "
					+ "VALUES (?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
			insertNewStudentInEnrollment.setString(1,s.getPIN());
			insertNewStudentInEnrollment.setInt(2,classID);
			insertNewStudentInEnrollment.setInt(3,2022);
		
			result = insertNewStudentInEnrollment.executeUpdate(); //inserts the studentPIN, classID, and enrollment year
		
			if (result == 1) check++;
		}
		
			catch(SQLException error) {
			 error.printStackTrace();
			}
		if(check == 2) JOptionPane.showMessageDialog(null, s.getfName() + " " + s.getlName() + " has been added to the class");
		else  JOptionPane.showMessageDialog(null, "An error has occurred. The student was not successfully added to the class");
		
		return result;
}


//inputs the students in the administrator's arraylist class
public void getStudentsInClass(Administrator a){
	try {
		stmt = conn.createStatement();
		String qStr = "SELECT Enrollment.ClassID, Student.FirstName, Student.LastName, Student.Gender, "
				+ "Student.StudentPIN, Student.DaysAttended, Student.DaysMissed FROM Enrollment "
				+ "INNER JOIN Student ON Enrollment.StudentPIN = Student.StudentPIN WHERE ClassID =  '" + a.getClassID() + "'";  //query
	
		rset = stmt.executeQuery(qStr); //executes query stored in the string
		int rowCount = 0;
		while(rset.next()) {   // Repeatedly process each row
			Student s = new Student (rset.getString("FirstName"), rset.getString("LastName"),  rset.getString("Gender"), 
					rset.getString("StudentPIN"), rset.getInt("daysAttended"), rset.getInt("daysMissed")); //create student with each attribute
			a.addStudentToClass(s); //adds the student to the administrator's class(stored as an arraylist)
			rowCount++;
     }
}
	catch (SQLException error) {
		error.printStackTrace(); //outputs error if datab
	}
}


//retrieves the admin's data by taking the PIN from the login as a parameter and return the corresponding admin info in an administrator object
public Administrator getAdminData(String PIN){
		Administrator a = new Administrator();
	    try {
		String qStr = "Select Class.ClassID, Administrator.FirstName, Administrator.LastName, Administrator.Gender,"
				+ "Administrator.AdminPIN FROM Class"
				+ " INNER JOIN Administrator ON Class.DeptID = Administrator.DeptID WHERE AdminPIN = '" + PIN + "'";  //query
		stmt = conn.createStatement(); //creates statement
	    rset = stmt.executeQuery(qStr); //executes query stored in the string
	   
	    while(rset.next()) {   // processes the row
	    	a = new Administrator(rset.getString("FirstName"), rset.getString("LastName"), rset.getString("Gender"),
        	rset.getString("AdminPIN"), rset.getInt("ClassID")); //inputs the admin data into an admin object
	    }
	    }
	    catch (SQLException error) {
			error.printStackTrace(); //outputs error if datab
		}
	    return a;
     }


//close the connection to the database
public void closeConnection() {
	try {
		conn.close(); //tries to close the connection to the database
	} catch (SQLException e) {
		e.printStackTrace(); //prints the stack trace if an error occurs
	}
}


}

