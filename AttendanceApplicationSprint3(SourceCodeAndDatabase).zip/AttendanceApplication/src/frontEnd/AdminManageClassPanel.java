package frontEnd;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;

import java.util.ArrayList;

import backEnd.AdministratorController;

public class AdminManageClassPanel extends JPanel {
		JPanel radioButtonContainer = new JPanel();
		final int CWIDTH = 400;
		final int CHEIGHT = 50;
		JButton cmdHome;
		JButton cmdSubmitAttendance;
		JButton cmdAddStudent;
		JButton cmdRemoveStudent;
		JLabel lblHeader;
			
	AdminManageClassPanel(){}
	AdminManageClassPanel(AdministratorController aController, ArrayList<RadioButtonGroup> groupList){
		
		
		int classSize = aController.administratorGetClassList().size();
		
		//creates a header label
		lblHeader = new JLabel ("             Manage Class Attendance");
		lblHeader.setPreferredSize(new Dimension(475,100));
		lblHeader.setFont(new Font("Serif", Font.BOLD, 28));
		
		//sets information for the home button
		cmdHome = new JButton("Home");
		cmdHome.setPreferredSize(new Dimension(250,50));
		cmdHome.setFont(new Font("Serif", Font.BOLD, 32));
		
		//sets information for the submit attendance button
		cmdSubmitAttendance = new JButton("Submit Attendance");
		cmdSubmitAttendance.setPreferredSize(new Dimension(165,30));
		cmdSubmitAttendance.setFont(new Font("Serif", Font.BOLD, 16));
		
		//sets information for the add student button
		cmdAddStudent = new JButton("Add Student");
		cmdAddStudent.setPreferredSize(new Dimension(165,30));
		cmdAddStudent.setFont(new Font("Serif", Font.BOLD, 16));
		
		//sets information for the remove student button
		cmdRemoveStudent = new JButton("Remove Student");
		cmdRemoveStudent.setPreferredSize(new Dimension(165,30));
		cmdRemoveStudent.setFont(new Font("Serif", Font.BOLD, 16));
				
		//creates the main container for this panel
		radioButtonContainer = new JPanel(new GridLayout(classSize + 3, 1));
				
		//creates the top of the grid containing labels
		JPanel topOfGrid = new JPanel();
		topOfGrid.setLayout(new GridLayout(1,3));
		topOfGrid.setBackground(Color.lightGray);
		
		JLabel lblName = new JLabel("     Name");
		lblName.setFont(new Font("Serif", Font.BOLD, 26));
		topOfGrid.add(lblName);
		
		JLabel lblPresent = new JLabel("    Present");
		lblPresent.setFont(new Font("Serif", Font.BOLD, 26));
		topOfGrid.add(lblPresent);
		
		JLabel lblAbsent = new JLabel("    Absent");
		lblAbsent.setFont(new Font("Serif", Font.BOLD, 26));
		topOfGrid.add(lblAbsent);
		
		//adds the top to the container
		radioButtonContainer.add(topOfGrid);
		
		//iterates through the class and creates a button group for each student
		for (int i=0; i < classSize; i++) {
			
		String currName = aController.administratorGetClassList().get(i).getfName() + " " 
		+ aController.administratorGetClassList().get(i).getlName(); //sets the current students name as currName	

		RadioButtonGroup group = new RadioButtonGroup(new JLabel(currName), new JRadioButton(), new JRadioButton());
		radioButtonContainer.add(group); //adds the group of components to the grid
		groupList.add(group); //adds the group to an arraylist
		}
		
		//creates the bottom of the grid containing the add and remove buttons
		JPanel bottomOfGrid = new JPanel();
		bottomOfGrid.setLayout(new FlowLayout());
		bottomOfGrid.setBackground(Color.lightGray);
		bottomOfGrid.add(cmdAddStudent);
		bottomOfGrid.add(cmdRemoveStudent);
		
		//creates the bottom of the grid containing the submit button
		JPanel midBottomOfGrid = new JPanel();
		midBottomOfGrid.setLayout(new FlowLayout());
		midBottomOfGrid.setBackground(Color.lightGray);
		midBottomOfGrid.add(cmdSubmitAttendance);
		
		//adds the midbottom and bottom piece to the grid
		radioButtonContainer.add(midBottomOfGrid);
		radioButtonContainer.add(bottomOfGrid);
		
		//adds the radiobutton container to the scroll pane and sets info about the scroll pane
		JScrollPane scrollPane = new JScrollPane(radioButtonContainer);
		scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS); 
		scrollPane.setPreferredSize(new Dimension(450, 400));
			
		//puts the scroll pane into a panel for the center of the screen
		JPanel centerPanel = new JPanel();
		centerPanel.setBackground(Color.WHITE);
		centerPanel.add(scrollPane);
		
		//puts the home button in a panel for the bottom of the screen
		JPanel bottomPanel = new JPanel();
		bottomPanel.setLayout(new FlowLayout());
		bottomPanel.add(cmdHome);
		bottomPanel.setBackground(Color.WHITE);
		
		//puts the header in the top panel
		JPanel topPanel = new JPanel();
		topPanel.setBackground(Color.white);
		topPanel.add(lblHeader);
		
		//sets info about this panel and adds the inner panels to the screen
		setLayout(new BorderLayout());
		setBackground(Color.WHITE);
		add(centerPanel, BorderLayout.CENTER);
		add(bottomPanel, BorderLayout.SOUTH);
		add(topPanel, BorderLayout.NORTH);
		
		}
	
	//this nested class creates a button group for each student label and radio buttons
	class RadioButtonGroup extends JPanel{
		JLabel lblStudentName;
		JRadioButton rButton1;
		JRadioButton rButton2;
		ButtonGroup bGroup;
		
		RadioButtonGroup(JLabel name, JRadioButton b1, JRadioButton b2){
			setBackground(Color.WHITE);
		
			setLayout(new GridLayout(1,3));
			
			this.lblStudentName = name;
			this.rButton1 = b1;
			this.rButton2 = b2;
			this.bGroup = new ButtonGroup();
			
			JPanel leftPanel = new JPanel();
			leftPanel.add(lblStudentName);
			leftPanel.setBackground(Color.lightGray);
			
			JPanel midPanel = new JPanel();
			midPanel.add(rButton1);
			midPanel.setBackground(Color.lightGray);
			
			JPanel rightPanel = new JPanel();
			rightPanel.add(rButton2);
			rightPanel.setBackground(Color.lightGray);
	
			lblStudentName.setFont(new Font("Serif", Font.PLAIN, 18));
			
			
			rButton1.setBackground(Color.lightGray);
			rButton2.setBackground(Color.lightGray);
			
			bGroup.add(rButton1);
			bGroup.add(rButton2);
			
			add(leftPanel);
			add(midPanel);
			add(rightPanel);
			
			setPreferredSize(new Dimension(CWIDTH,CHEIGHT));
		}
		}
	
	}

