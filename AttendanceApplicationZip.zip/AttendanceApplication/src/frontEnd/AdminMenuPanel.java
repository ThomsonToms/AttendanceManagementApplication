/*
 * Filename:    AdminMenuPanel.java
 * Package:     frontEnd
 * Project:     Attendance Management System
 * Author:      Jacob Bianco, Comlan Acolitse, and Thomson Toms
 * Section:     IST 311
 * Assignment:  Sprint 3
 * Description: This class contains the panel that is displayed for the admin menu panel
 * Date Created: 11/1/22
 * Date modified: 11/1/22
 *
 */
package frontEnd;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import backEnd.AdministratorController;

public class AdminMenuPanel extends JPanel {

	//creates some components for the panel
	JLabel  lblWelcome;
	JButton cmdManageAttendance, cmdViewAttendance, cmdViewMyInfo, cmdLogOut;
	JPanel topPanel, centerPanel, nestedPanel1, nestedPanel2, nestedPanel3, nestedPanel4, nestedPanel5;
	
	final int CWIDTH = 300;
	final int CHEIGHT = 100;

	AdminMenuPanel(){
		
		//sets information about the buttons and labels such as size and font
		lblWelcome = new JLabel ("Welcome to the Attendance Application");
		lblWelcome.setPreferredSize(new Dimension(CWIDTH+175,CHEIGHT));
		lblWelcome.setFont(new Font("Serif", Font.BOLD, 28));
		
		
		cmdManageAttendance = new JButton ("Manage Class Attendance");
		cmdManageAttendance.setPreferredSize(new Dimension(CWIDTH,CHEIGHT));
		cmdManageAttendance.setFont(new Font("Serif", Font.BOLD, 18));
		
		cmdViewAttendance = new JButton ("View Class Attendance");
		cmdViewAttendance.setPreferredSize(new Dimension(CWIDTH,CHEIGHT));
		cmdViewAttendance.setFont(new Font("Serif", Font.BOLD, 18));
		
		cmdViewMyInfo = new JButton ("View Info");
		cmdViewMyInfo.setPreferredSize(new Dimension(CWIDTH,CHEIGHT));
		cmdViewMyInfo.setFont(new Font("Serif", Font.BOLD, 18));
		
		cmdLogOut = new JButton ("Log Out");
		cmdLogOut.setPreferredSize(new Dimension(CWIDTH,CHEIGHT));
		cmdLogOut.setFont(new Font("Serif", Font.BOLD, 18));
		
		//creates multiple nested panels which contain components
		nestedPanel1 = new JPanel();
		nestedPanel1.add(lblWelcome);
		nestedPanel1.setBackground(Color.WHITE);
		
		nestedPanel2 = new JPanel();
		nestedPanel2.add(cmdManageAttendance);
		nestedPanel2.setBackground(Color.WHITE);
		
		nestedPanel3 = new JPanel();
		nestedPanel3.add(cmdViewAttendance);
		nestedPanel3.setBackground(Color.WHITE);
		
		nestedPanel4 = new JPanel();
		nestedPanel4.add(cmdViewMyInfo);
		nestedPanel4.setBackground(Color.WHITE);
		
		nestedPanel5 = new JPanel();
		nestedPanel5.add(cmdLogOut);
		nestedPanel5.setBackground(Color.WHITE);
		
		//creates a panel for the top of the screen
		topPanel = new JPanel();
		topPanel.setLayout(new GridLayout(1,1));
		topPanel.add(nestedPanel1);
		topPanel.setBackground(Color.LIGHT_GRAY);
		
		//creates a panel for the middle of the screen
		centerPanel = new JPanel();
		centerPanel.setLayout(new GridLayout(4,1));
		centerPanel.add(nestedPanel2);
		centerPanel.add(nestedPanel3);
		centerPanel.add(nestedPanel4);
		centerPanel.add(nestedPanel5);
		
		//sets the layout of the screen and adds the main panels to the screen in specific spots
		setLayout(new BorderLayout());
		add(topPanel, BorderLayout.NORTH);
		add(centerPanel, BorderLayout.CENTER);
	}
}
