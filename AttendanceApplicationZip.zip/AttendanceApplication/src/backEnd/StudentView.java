package backEnd;
import java.sql.SQLException;
import java.util.Scanner;

/*
 * Filename:    StudentView.java
 * Package:     No package
 * Project:     Attendance Management System
 * Author:      Jacob Bianco, Comlan Acolitse, and Thomson Toms
 * Section:     IST 311
 * Assignment:  Sprint 1
 * Description: The StudentView class just prints the information that a student needs,
 *              which includes: Name, Gender, PIN, and attendance.
 * Date Created: 9/3/22
 * Date modified:10/6/22
 *
 */

public class StudentView
{

    // Prints exit message for a student
    public static void exitProgram(Student model) {
        System.out.println(model.getfName() + ", thank you for using the Attendance Application to check your grades.");
    }
    
    
  //displays the student menu for the main method
    public static void displayMenu(StudentActions sData, Student  model) throws SQLException  {
    	boolean run = true;
    	System.out.println("\nWelcome to your Attendance Application. Please choose one of the following options by typing in the corresponding number.");
    	
    	while(run) { //loops the menu while run is true
    	System.out.println("1: Check your attendance statistics for the school year.");
    	System.out.println("2: Exit the application.");
    	
    	Scanner sc = new Scanner(System.in);
    	int num = sc.nextInt(); //receives input for the menu option the admin chooses
    	
    	switch(num) {
    	case 1: 
    		printStudentAttendance(model);
    		break;
    	case 2: 
    		sData.closeConnection();//closes the connection to the database
    	    exitProgram(model); //displays exit message for student
    	    run = false;
    		break;
    		}	
    	}
    }   
    
    
    // Print Student Information
    public static void printStudentAttendance(Student model)
    {
        System.out.println("Name: " + model.getfName() + " " + model.getlName());
        System.out.println("Gender: " + model.getGender());
        System.out.println("PIN Number: " + model.getPIN());
        System.out.println("Days Attended: " + model.getDaysAttended());
        System.out.println("Days Absent: " + model.getDaysMissed() + "\n");
    }
}