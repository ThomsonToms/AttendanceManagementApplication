/*
 * Filename:    AdminViewInfoPanel.java
 * Package:     frontEnd
 * Project:     Attendance Management System
 * Author:      Jacob Bianco, Comlan Acolitse, and Thomson Toms
 * Section:     IST 311
 * Assignment:  Sprint 3
 * Description: This class contains the panel that is displayed for the administrator's view info screen
 * Date Created: 11/1/22
 * Date modified: 11/1/22
 * */
package frontEnd;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import backEnd.AdministratorController;

public class AdminViewInfoPanel extends JPanel{
	
	//creates some components for the panel
	JPanel centerPanel, bottomPanel, topPanel;
	JLabel lblPIN1, lblName1, lblGender1,  lblClasses1, lblHeader;
	JTextField lblPIN2, lblName2, lblGender2,lblClasses2;
	JButton cmdHome;
	
	//sets some constants for the panel
	final int CWIDTH = 300;
	final int CHEIGHT = 100;
	final int SIZE = 36;
	
	//empty default constructor
	AdminViewInfoPanel(){}
	
	//overloaded constructor
	AdminViewInfoPanel(AdministratorController aController){
		
		//typecasts the admin's ID as an integer and stores it in a string using toString method
		Integer iClassID = (Integer) aController.administratorGetClassID();
		String sClassID = iClassID.toString();
		
		//sets information about the components of the screen
		lblHeader = new JLabel ("                  Personal Information");
		lblHeader.setPreferredSize(new Dimension(475,100));
		lblHeader.setFont(new Font("Serif", Font.BOLD, 28));
		
		cmdHome = new JButton("Home");
		cmdHome.setPreferredSize(new Dimension(CWIDTH-50,CHEIGHT-50));
		cmdHome.setFont(new Font("Serif", Font.BOLD, SIZE-4));

		lblPIN1 = new JLabel ("      PIN:");
		lblPIN1.setPreferredSize(new Dimension(CWIDTH,CHEIGHT));
		lblPIN1.setFont(new Font("Serif", Font.BOLD, SIZE));
		
		lblPIN2 = new JTextField ("            "  + aController.getAdmininistratorPIN());
		lblPIN2.setPreferredSize(new Dimension(CWIDTH,CHEIGHT));
		lblPIN2.setFont(new Font("Serif", Font.BOLD, SIZE));
		lblPIN2.setEditable(false);
		
		lblName1 = new JLabel ("      Name:");
		lblName1.setPreferredSize(new Dimension(CWIDTH,CHEIGHT));
		lblName1.setFont(new Font("Serif", Font.BOLD, SIZE));
		
		lblName2 = new JTextField ("    " + aController.getAdmininistratorfName() + " " + aController.getAdmininistratorlName());
		lblName2.setPreferredSize(new Dimension(CWIDTH,CHEIGHT));
		lblName2.setFont(new Font("Serif", Font.BOLD, SIZE));
		lblName2.setEditable(false);
		
		lblGender1 = new JLabel ("      Gender:");
		lblGender1.setPreferredSize(new Dimension(CWIDTH,CHEIGHT));
		lblGender1.setFont(new Font("Serif", Font.BOLD, SIZE));
		
		lblGender2 = new JTextField ("              "  + aController.getAdmininistratorGender());
		lblGender2.setPreferredSize(new Dimension(CWIDTH,CHEIGHT));
		lblGender2.setFont(new Font("Serif", Font.BOLD, SIZE));
		lblGender2.setEditable(false);
		
		lblClasses1 = new JLabel ("      Class ID:");
		lblClasses1.setPreferredSize(new Dimension(CWIDTH,CHEIGHT));
		lblClasses1.setFont(new Font("Serif", Font.BOLD, SIZE));
		
		lblClasses2 = new JTextField ("              "  + sClassID);
		lblClasses2.setPreferredSize(new Dimension(CWIDTH,CHEIGHT));
		lblClasses2.setFont(new Font("Serif", Font.BOLD, SIZE));
		lblClasses2.setEditable(false);
		
		centerPanel = new JPanel(new GridLayout(6,2));
		centerPanel.add(new JLabel());
		centerPanel.add(new JLabel());
		
		//creates multiple nested panels containing the components
		JPanel p1 = new JPanel();
		p1.add(lblPIN1);
		p1.setBackground(Color.WHITE);
		centerPanel.add(p1);
		
		JPanel p2 = new JPanel();
		p2.add(lblPIN2);
		p2.setBackground(Color.WHITE);
		centerPanel.add(p2);
		
		JPanel p3 = new JPanel();
		p3.add(lblName1);
		p3.setBackground(Color.WHITE);
		centerPanel.add(p3);
		
		JPanel p4 = new JPanel();
		p4.add(lblName2);
		p4.setBackground(Color.WHITE);
		centerPanel.add(p4);
		
		JPanel p5 = new JPanel();
		p5.add(lblGender1);
		p5.setBackground(Color.WHITE);
		centerPanel.add(p5);
		
		JPanel p6 = new JPanel();
		p6.add(lblGender2);
		p6.setBackground(Color.WHITE);
		centerPanel.add(p6);
		
		JPanel p7 = new JPanel();
		p7.add(lblClasses1);
		p7.setBackground(Color.WHITE);
		centerPanel.add(p7);
		
		JPanel p8 = new JPanel();
		p8.add(lblClasses2);
		p8.setBackground(Color.WHITE);
		centerPanel.add(p8);
		
		centerPanel.add(new JLabel());
		centerPanel.add(new JLabel());
		centerPanel.setBackground(Color.WHITE);
		
		bottomPanel = new JPanel();
		bottomPanel.setLayout(new FlowLayout());
		bottomPanel.add(cmdHome);
		bottomPanel.setBackground(Color.WHITE);
		
		topPanel = new JPanel();
		topPanel.setBackground(Color.white);
		topPanel.add(lblHeader);
		
		//sets the layout of the screen and adds each main component to the screen
		setLayout(new BorderLayout());
		add(centerPanel, BorderLayout.CENTER);
		add(bottomPanel, BorderLayout.SOUTH);
		add(topPanel, BorderLayout.NORTH);
		setBackground(Color.WHITE);
		
	}
	
}
