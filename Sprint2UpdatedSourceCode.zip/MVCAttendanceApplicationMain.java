import java.sql.SQLException;
import java.util.*;

/*
 * Filename:    MVCAttendanceApplicationMain.java
 * Package:     No package
 * Project:     Attendance Management System
 * Author:      Jacob Bianco, Comlan Acolitse, and Thomson Toms
 * Section:     IST 311
 * Assignment:  Sprint 2
 * Description: Main method contains a working version of the app which connects to a database and outputs to the console
 * Date Created: 9/3/22
 * Date modified:10/6/22
 *
 */
public class MVCAttendanceApplicationMain {
		
    //Main method
    public static void main(String args[]) throws SQLException{
    	char user = 'n'; //creates a char variable which corresponds to what type of user the user is(admin 'a' or student 's' or neither 'n')
    	String currentUserPIN = getUserPIN(); //receive the user's PIN and store it in a String(login prompt)
    	AdministratorActions aData = new AdministratorActions(); //creates an instance of the admin database class
    	StudentActions sData = new StudentActions(); //creates an instance of the student database class 
    	user = checkUserPIN(currentUserPIN, sData, aData); //validates that the user is in the database
    	
    	if(user == 'a') {
    		
    		Administrator model = new Administrator(); //creates admin model
    		model = aData.getAdminData(currentUserPIN); //inputs the admin data into a model 
    		AdministratorView view = new AdministratorView(); //creates a view object for an administrator
    	    AdministratorController controller = new AdministratorController(model, view, aData); //creates a controller for the admin
    	    controller.administratorGetStudentsInClass(); //inputs the students into the admin class
    	    controller.displayAdministratorMenu(); //displays menu for admin
    	   
        }
    	else if(user == 's') {
    		
    		Student model = new Student(); //creates student model
    		model = sData.getStudentData(currentUserPIN); //inputs the student data into a model 
    		StudentView view = new StudentView(); //creates a view object for a student
    	    StudentController controller = new StudentController(model, view, sData); //creates a controller for the student
    	    controller.displayStudentMenu(); //displays menu for student
    	    
    	}
    	
    	else 
    		
    		System.out.println("Exiting application.");
    	
    }
 

//prompts the user to enter their PIN and returns the PIN as a string
public static String getUserPIN() { 
    	System.out.println("Welcome to your attendance application. Please enter your  5 digit PIN to log in.");
    	Scanner sc = new Scanner(System.in); 
    	String s = sc.nextLine(); //receives input into the string
    	return s; // returns the string 
    	}


//checks a user's PIN for validation in the database, and returns a corresponding character value
public static char checkUserPIN(String currentUserPIN, StudentActions sData, AdministratorActions aData) { 
		char user = 'n'; //default value for user
    	try { 
		 if(aData.getAdminData(currentUserPIN).getUserPIN() != "null") { //checks if the entered user pin is in the Admin table 
			 user = 'a'; //changes user to 'a' to indicate to the program that the user is an admin
			 return user; //returns the updated user variable
		 }
		 else if(sData.getStudentData(currentUserPIN).getUserPIN() != "null") { //checks if the entered user pin is in Student table
			 user = 's'; //changes user to 's' to indicate to the program that the user is an student
			 return user; //returns the updated user variable
		 }
	     else { //the else statement returns the same user variable back to the program because the pin was not found in the database
	    	 System.out.println("The PIN is invalid.");
	    	 return user;
	     }
		}
    	catch (SQLException e) {
			e.printStackTrace(); //prints the stack trace if something goes wrong when contacting the database
		}
		return user; //returns user to the program
    }

}
