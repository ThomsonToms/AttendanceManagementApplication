/*
 * Filename:    Student.java
 * Package:     No package
 * Project:     Attendance Management System
 * Author:      Jacob Bianco, Comlan Acolitse, and Thomson Toms
 * Section:     IST 311
 * Assignment:  Sprint 1
 * Description: The Student class inherits the methods from the User class and implements methods for
 *              a student to use.
 * Date Created: 9/3/22
 * Date modified:9/15/22
 *
 */
public class Student extends User {
    private int daysMissed; //days that the student missed
    private int daysAttended; //days that the student attended
    private int daysPassed; //days of the school year that passed

    //Default constructor
    Student(){
        super();
        daysMissed = 0;
        daysAttended = 0;
        daysPassed = 0;
    }

    //Overloaded constructor
    Student(String fName, String lName, String userGender, String PIN, int daysMissed, int daysAttended){
        super(fName, lName, userGender, PIN);
        this.daysMissed = daysMissed;
        this.daysAttended = daysAttended;
    }

    //increments the days missed and adds it to the previous value
    public void setDaysMissed(int daysMissed){this.daysMissed += daysMissed;}

    // This method returns the days that the student missed
    public int getDaysMissed(){return daysMissed;}

    //increments the days attended and adds it to the previous value, note that
    //this method is here so the admin can access. This cannot be used by the student
    public void setDaysAttended(int daysAttended){this.daysAttended += daysAttended;}

    //This method returns/prints the days the student attended or were marked by admin
    public int getDaysAttended(){return daysAttended;}

    // This method is here so the admin can access. This cannot be used by the student
    public void setDaysPassed(int daysMissed, int daysAttended){daysPassed = (daysMissed + daysAttended);}

    //returns the days passed as an integer
    public int getDaysPassed(){return daysPassed;}

    
}
