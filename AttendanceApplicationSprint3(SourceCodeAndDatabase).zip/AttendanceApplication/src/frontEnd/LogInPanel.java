package frontEnd;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class LogInPanel extends JPanel {
	//creates a picture for the program to display on the log in screen
	final String icon = "C:/Users/jacob/eclipse-workspace/AttendanceApplication/aaimage.png";
	
	//creates some components for the loginpanel
	JButton cmdSubmit;
	JTextField txtPIN;
	JLabel lblPIN;
	JLabel lblIcon; 
	JPanel topPanel;
	JPanel centerPanel;
	
	LogInPanel(){
		//sets the size of the icon
		lblIcon = new JLabel(new ImageIcon(icon));
		lblIcon.setPreferredSize(new Dimension(200,165));
		
		//sets name and size of submit button
		cmdSubmit = new JButton ("Submit");
		cmdSubmit.setPreferredSize(new Dimension(100,50));
		cmdSubmit.setFont(new Font("Serif", Font.BOLD, 18));
		
		//sets length and size of the PIN text field
		txtPIN = new JTextField (5);
		txtPIN.setDocument(new LengthRestrictedDocument(5));
		txtPIN.setPreferredSize(new Dimension(50,50));
		txtPIN.setFont(new Font("Serif", Font.BOLD, 25));
		
		//sets the name for the PIN label
		lblPIN = new JLabel("Please enter your 5-Digit PIN");
		lblPIN.setFont(new Font("Serif", Font.BOLD, 18));
		
		//adds components to the top panel and customizes the panel
		topPanel = new JPanel();
		topPanel.add(lblIcon);
		topPanel.setPreferredSize(new Dimension(150,150));
		topPanel.setBackground(Color.WHITE);
		
		//adds components to the center panel and customizes the panel
		centerPanel = new JPanel();
		centerPanel.add(lblPIN);
		centerPanel.add(txtPIN);
		centerPanel.add(cmdSubmit);
		centerPanel.setBackground(Color.WHITE);
		
		//adds components to the login panel using border layout
		setLayout(new BorderLayout());
		add(topPanel, BorderLayout.NORTH);
		add(centerPanel, BorderLayout.CENTER);
	}
}
