
/*
 * Filename:    User.java
 * Package:     No package
 * Project:     Attendance Management System
 * Author:      Jacob Bianco, Comlan Acolitse, and Thomson Toms
 * Section:     IST 311
 * Assignment:  Sprint 1
 * Description: The User class contains attributes and methods that all users should have
 * Date Created: 9/3/22
 * Date modified:9/8/22
 *
 */
public abstract class User {

	    private String fName, lName; //user's name
	    private String userGender;//user's gender
	    private String PIN;//user's PIN

	    //default constructor for a user
	    User(){
	        fName = lName = "";
	        userGender = "";
	        PIN = "null";
	    }

	    
	    //overloaded constructor for a user, taking the user's name and gender as arguments
	    User(String fName, String lName, String userGender, String PIN){
	        this.fName = fName;//sets the first name of the user
	        this.lName = lName;//sets the last name of the user
	        this.userGender = userGender;//sets the gender of the user
	        this.PIN = PIN;//sets a user's PIN
	    }

	    
	    //sets a user's first name
	    public void setUserfName(String fName){this.fName = fName;}
	    
	    
	    //sets a user's last name
	    public void setUserlName(String lName){this.lName = lName;}
	    
	    
	    //returns a user's first name as a string
	    public String getUserfName(){return fName;}
	    
	    
	    //returns a user's last name as a string
	    public String getUserlName(){return lName;}

	    
	    //sets a user's gender
	    public void setUserGender(String userGender){this.userGender = userGender;}

	    
	    //returns a user's gender as a string
	    public String getUserGender(){return userGender;}

	    
	    //sets a PIN for a user
	    public void setUserPIN(String PIN){
	        this.PIN = PIN;
	    }

	    
	    //returns the user's PIN as a string
	    public String getUserPIN(){return PIN;}
	}

