package frontEnd;
import javax.swing.*;
import backEnd.StudentController;
import java.awt.*;        

public class StudentViewInfoPanel extends JPanel
{
		JLabel lblHeader;
		JLabel lblOne;
		JLabel lblTwo;
		JLabel lblThree;
		JLabel lblFour;
		JLabel lblFive;
		JLabel lblSix;
		JButton cmdHome;
	
		final int CWIDTH = 300;
		final int CHEIGHT = 100;
		final int SIZE = 36;
	
		public StudentViewInfoPanel(){}
		
		public StudentViewInfoPanel(StudentController sController)
		{
			Integer daysAttended = (Integer) sController.getStudentDaysAttended();
			String sDaysAttended = daysAttended.toString();
			
			Integer daysMissed = (Integer) sController.getStudentDaysMissed();
			String sDaysMissed = daysMissed.toString();
			
			lblHeader = new JLabel ("                 Personal Information");
			lblHeader.setPreferredSize(new Dimension(475,100));
			lblHeader.setFont(new Font("Serif", Font.BOLD, 28));
			
			lblOne = new JLabel("    PIN: ");
			lblOne.setPreferredSize(new Dimension(CWIDTH,CHEIGHT));
			lblOne.setFont(new Font("Serif", Font.BOLD, SIZE));
			
			lblTwo = new JLabel("    Name: ");
			lblTwo.setPreferredSize(new Dimension(CWIDTH,CHEIGHT));
			lblTwo.setFont(new Font("Serif", Font.BOLD, SIZE));
			
			lblThree = new JLabel("    Gender: ");
			lblThree.setPreferredSize(new Dimension(CWIDTH,CHEIGHT));
			lblThree.setFont(new Font("Serif", Font.BOLD, SIZE));
			
			lblFour = new JLabel("    Days Attended: ");
			lblFour.setPreferredSize(new Dimension(CWIDTH,CHEIGHT));
			lblFour.setFont(new Font("Serif", Font.BOLD, SIZE));
			
			lblFive = new JLabel("    Days Missed: ");
			lblFive.setPreferredSize(new Dimension(CWIDTH,CHEIGHT));
			lblFive.setFont(new Font("Serif", Font.BOLD, SIZE));
			
			cmdHome = new JButton("Home ");
			cmdHome.setPreferredSize(new Dimension(CWIDTH-50,CHEIGHT-50));
			cmdHome.setFont(new Font("Serif", Font.BOLD, SIZE));
			
		
			JTextField label2 = new JTextField("            "  + sController.getStudentPIN());
			label2.setPreferredSize(new Dimension(CWIDTH,CHEIGHT));
			label2.setFont(new Font("Serif", Font.BOLD, SIZE));
			label2.setEditable(false);
			
			JTextField label3 = new JTextField("    " + sController.getStudentfName() + " " + sController.getStudentlName());
			label3.setPreferredSize(new Dimension(CWIDTH,CHEIGHT));
			label3.setFont(new Font("Serif", Font.BOLD, SIZE));
			label3.setEditable(false);
			
			JTextField label4 = new JTextField("              "  + sController.getStudentGender());
			label4.setPreferredSize(new Dimension(CWIDTH,CHEIGHT));
			label4.setFont(new Font("Serif", Font.BOLD, SIZE));
			label4.setEditable(false);
			
			JTextField label5 = new JTextField("              "  + sDaysAttended);
			label5.setPreferredSize(new Dimension(CWIDTH,CHEIGHT));
			label5.setFont(new Font("Serif", Font.BOLD, SIZE));
			label5.setEditable(false);
			
			JTextField label6 = new JTextField("              " + sDaysMissed);
			label6.setPreferredSize(new Dimension(CWIDTH,CHEIGHT));
			label6.setFont(new Font("Serif", Font.BOLD, SIZE));
			label6.setEditable(false);
			
			 JPanel topPannel = new JPanel();
			 topPannel.add(lblOne);
			 topPannel.setPreferredSize(new Dimension(CWIDTH,CHEIGHT));
			 topPannel.setBackground(Color.WHITE);
			 
			 JPanel topPannelb = new JPanel();
			 topPannelb.add(label2);
			 topPannelb.setPreferredSize(new Dimension(CWIDTH,CHEIGHT));
			 topPannelb.setBackground(Color.WHITE);
			 
			 JPanel midPannel = new JPanel();
			 midPannel.add(lblTwo);
			 midPannel.setPreferredSize(new Dimension(CWIDTH,CHEIGHT));
			 midPannel.setBackground(Color.WHITE);
			 
			 JPanel midPannelb = new JPanel();
			 midPannelb.add(label3);
			 midPannelb.setPreferredSize(new Dimension(CWIDTH,CHEIGHT));
			 midPannelb.setBackground(Color.WHITE);
			 
			 JPanel mid1Pannel = new JPanel();
			 mid1Pannel.add(lblThree);
			 mid1Pannel.setBackground(Color.WHITE);
			 
			 JPanel mid1Pannelb = new JPanel();
			 mid1Pannelb.add(label4);
			 mid1Pannelb.setBackground(Color.WHITE);
			 
			 JPanel mid2Pannel = new JPanel();
			 mid2Pannel.add(lblFour);
			 mid2Pannel.setBackground(Color.WHITE);
			 
			 JPanel mid2Pannelb = new JPanel();
			 mid2Pannelb.add(label5);
			 mid2Pannelb.setBackground(Color.WHITE);
			 
			 JPanel mid3Pannel = new JPanel();
			 mid3Pannel.add(lblFive);
			 mid3Pannel.setBackground(Color.WHITE);
			 
			 JPanel mid3Pannelb = new JPanel();
			 mid3Pannelb.add(label6);
			 mid3Pannelb.setBackground(Color.WHITE);
			 
			 JPanel mid4Pannel = new JPanel();
			 mid4Pannel.add(cmdHome);
			 mid4Pannel.setBackground(Color.WHITE);
			 
			 JPanel panel = new JPanel(new GridLayout(6, 2));
			 
			 JPanel bottomPanel = new JPanel(new FlowLayout());
			 bottomPanel.add(mid4Pannel);
			 bottomPanel.setBackground(Color.WHITE);
			 
			//puts the header in the top panel
			JPanel topPanel = new JPanel();
			topPanel.setBackground(Color.white);
			topPanel.add(lblHeader);
				 
			 panel.add(topPannel);
			 panel.add(topPannelb);
			 panel.add(midPannel);
			 panel.add(midPannelb);
			 panel.add(mid1Pannel);
			 panel.add(mid1Pannelb);
			 panel.add(mid2Pannel);
			 panel.add(mid2Pannelb);
			 panel.add(mid3Pannel);
			 panel.add(mid3Pannelb);
			 panel.setBackground(Color.WHITE);	 
			 
			 
			 setLayout(new BorderLayout());
			 setBackground(Color.WHITE);
			 add(panel, BorderLayout.CENTER);
			 add(bottomPanel, BorderLayout.SOUTH);
			 add(topPanel, BorderLayout.NORTH);
			
}
}

