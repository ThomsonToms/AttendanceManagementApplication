package frontEnd;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.UIManager;

import backEnd.AdministratorController;

public class AdminRemoveStudentPanel extends JPanel {
	JButton bButton, hButton, sButton;
	JTextField pinText;
	
	AdminRemoveStudentPanel(){}
	AdminRemoveStudentPanel(AdministratorController aController){
		setLayout(new BorderLayout());
		
		JLabel lblHeader = new JLabel("    Remove a Student");
	    lblHeader.setPreferredSize(new Dimension(275,100));
		lblHeader.setFont(new Font("Serif", Font.BOLD, 28));
		lblHeader.setBackground(Color.WHITE);
		
		JPanel headerPanel = new JPanel(new FlowLayout());
		headerPanel.setPreferredSize(new Dimension(475,100));
		headerPanel.setFont(new Font("Serif", Font.BOLD, 28));
		headerPanel.setBackground(Color.WHITE);
		headerPanel.add(lblHeader);
		
		JPanel centerPanel = new JPanel(new GridLayout(2,1));
		centerPanel.setPreferredSize(new Dimension(475,100));
		centerPanel.setFont(new Font("Serif", Font.BOLD, 28));
		centerPanel.setBackground(Color.WHITE);
		
		JPanel midPanel = new JPanel(new FlowLayout());
		midPanel.setBackground(Color.WHITE);
		midPanel.setPreferredSize(new Dimension(475,100));
		
		JPanel topPanel = new JPanel(new FlowLayout());
		topPanel.setBackground(Color.WHITE);
		topPanel.setPreferredSize(new Dimension(475,50));
		
		JLabel pinLabel = new JLabel("Enter the Student's PIN:");
        pinLabel.setPreferredSize(new Dimension(275,50));
        pinLabel.setFont(new Font("Serif", Font.BOLD, 25));;
		pinLabel.setBackground(Color.WHITE);
		midPanel.add(pinLabel);
		
		pinText = new JTextField(5);
		pinText.setDocument(new LengthRestrictedDocument(5));
		pinText.setPreferredSize(new Dimension(50,50));
		pinText.setFont(new Font("Serif", Font.BOLD, 25));
		midPanel.add(pinText);
		
		sButton = new JButton ("Submit  ");
		sButton.setPreferredSize(new Dimension(100,50));
		sButton.setFont(new Font("Serif", Font.BOLD, 18));
		midPanel.add(sButton);
		
		add(centerPanel, BorderLayout.CENTER);
		JPanel bottomPanel = new JPanel (new FlowLayout());
		bottomPanel.setBackground(Color.white);
		
		bButton = new JButton("Back");
		bButton.setPreferredSize(new Dimension(250,50));
		bButton.setFont(new Font("Serif", Font.BOLD, 32));
		bottomPanel.add(bButton);
		
		hButton = new JButton("Home");
		hButton.setPreferredSize(new Dimension(250,50));
		hButton.setFont(new Font("Serif", Font.BOLD, 32));
		bottomPanel.add(hButton); 
		
		centerPanel.add(topPanel);
		centerPanel.add(midPanel);

		add(headerPanel, BorderLayout.NORTH);
		add(centerPanel, BorderLayout.CENTER);
		add(bottomPanel, BorderLayout.SOUTH);
		
	}
}
