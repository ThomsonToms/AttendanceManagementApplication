/*
 * Filename:    ContainerPanel.java
 * Package:     frontEnd
 * Project:     Attendance Management System
 * Author:      Jacob Bianco, Comlan Acolitse, and Thomson Toms
 * Section:     IST 311
 * Assignment:  Sprint 3
 * Description: This class is the container panel for every panel that is used throughout the program's GUI
 * Date Created: 11/1/22
 * Date modified: 11/1/22
 * */
package frontEnd;

//imports all of the necessary classes
import java.awt.CardLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import backEnd.Administrator;
import backEnd.AdministratorActions;
import backEnd.AdministratorController;
import backEnd.AdministratorView;
import backEnd.Student;
import backEnd.StudentActions;
import backEnd.StudentController;
import backEnd.StudentView;
import frontEnd.AdminManageClassPanel.RadioButtonGroup;

public class ContainerPanel extends JPanel implements ActionListener {
	
	//creates a cardlayout instance
	CardLayout cl = new CardLayout();
	
	//creates all of the objects needed to communicate with the backend for a student 
	StudentController sController;
	StudentActions sData = new StudentActions();
	StudentView sView = new StudentView(); 
	Student sModel = new Student(); 
	
	//creates all of the objects needed to communicate with the backend for an admin
	AdministratorController aController;
	AdministratorActions aData =  new AdministratorActions();
	AdministratorView aView = new AdministratorView(); 
	Administrator aModel = new Administrator(); 
	
	char user = 'n';
	
	//creates each panel needed for the program
	LogInPanel logInPanel = new LogInPanel();
	AdminMenuPanel adminMenuPanel = new AdminMenuPanel();
	AdminManageClassPanel adminManageClassPanel = new AdminManageClassPanel();
	AdminViewClassPanel adminViewClassPanel = new AdminViewClassPanel();
	AdminViewInfoPanel adminViewInfoPanel = new AdminViewInfoPanel();
	AdminAddStudentPanel adminAddStudentPanel = new AdminAddStudentPanel();
	AdminRemoveStudentPanel adminRemoveStudentPanel = new AdminRemoveStudentPanel();
	StudentMenuPanel studentMenuPanel = new StudentMenuPanel();
	StudentViewInfoPanel studentViewInfoPanel = new StudentViewInfoPanel();
	
	//creates an arraylist which is used to group buttons for student attendance in the manage attendance panel
	ArrayList<RadioButtonGroup> groupList = new ArrayList<>();

	ContainerPanel(){
		
	//sets the containers layout and adds each panel to the container 
	setLayout(cl);
	add(logInPanel, "LogIn");
	
	//shows the logIn screen when the program starts
	cl.show(this, "LogIn");
		
	//creates an action listener for the submit button in the login panel
	logInPanel.cmdSubmit.addActionListener(this);
	}
	
//enacts certain actions on button clicks throughout the program
public void actionPerformed(ActionEvent e) {
		String key = e.getActionCommand(); //inputs the action command to a string as the key
		
		switch(key) {
		
		case "Submit":
			submitEvent();//calls the method for when the submit button is clicked
			break;
		
		case "Submit ":
			addStudentEvent();//calls the method for when the add student button is clicked
			break;	
			
		case "Submit  ":
			removeStudentEvent();//calls the method for when the remove student button is clicked
			break;	
			
		case "Manage Class Attendance":
			cl.show(this, "AdminManageClass"); // shows the manage class screen
			break;
		
		case "View Class Attendance":
			cl.show(this, "AdminViewClass"); //shows the view class screen
			break;
			
		case "Submit Attendance":
			submitAttendanceEvent(); //calls the function when the submit attendance button is clicked
			break;	
			
		case "View Info":
			cl.show(this, "AdminViewInfo"); //shows the view info screen for admins
			break;
			
		case "View Info ":
			cl.show(this, "StudentViewInfo"); //shows the view info screen for students
			break;
			
		case "Home":
			cl.show(this, "AdminMenu"); //shows the admin menu when home is clicked
			break;
		
		case "Home ":
			cl.show(this, "StudentMenu");//shows the student menu when home is clicked
			break;
			
		case "Add Student":
			cl.show(this, "AdminAddStudent"); //shows the add student screen upon the button click
			break;
			
		case "Remove Student":
			cl.show(this, "AdminRemoveStudent"); //shows the remove student screen upon a button click
			break;
			
		case "Log Out":
			cl.show(this, "LogIn"); //returns to the log in screen
			break;	
			
		case "Back":
			cl.show(this, "AdminManageClass"); //returns to the manage class screen
			break;	
		}
}

//updates the screen components when an admin logs in
public void updateAdminScreen(AdministratorController aController) {
	//updates each panel with the "controller's" info
	this.adminMenuPanel = new AdminMenuPanel();
	this.adminManageClassPanel = new AdminManageClassPanel(aController, groupList);
	this.adminViewClassPanel = new AdminViewClassPanel(aController);
	this.adminViewInfoPanel = new AdminViewInfoPanel(aController);
	this.adminAddStudentPanel = new AdminAddStudentPanel(aController);
	this.adminRemoveStudentPanel = new AdminRemoveStudentPanel(aController);
	
	//adds each panel to the card layout 
	add(adminMenuPanel, "AdminMenu");
	add(adminManageClassPanel, "AdminManageClass");
	add(adminViewClassPanel, "AdminViewClass");
	add(adminViewInfoPanel, "AdminViewInfo");
	add(adminAddStudentPanel, "AdminAddStudent");
	add(adminRemoveStudentPanel, "AdminRemoveStudent");
	
	//adds button listeners for the buttons in the admin's panels
	adminMenuPanel.cmdManageAttendance.addActionListener(this);
	adminMenuPanel.cmdViewAttendance.addActionListener(this);
	adminMenuPanel.cmdViewMyInfo.addActionListener(this);
	adminMenuPanel.cmdLogOut.addActionListener(this);
	adminViewInfoPanel.cmdHome.addActionListener(this);
	adminViewClassPanel.cmdHome.addActionListener(this);
	adminManageClassPanel.cmdHome.addActionListener(this);
	adminManageClassPanel.cmdSubmitAttendance.addActionListener(this);
	adminManageClassPanel.cmdAddStudent.addActionListener(this);
	adminManageClassPanel.cmdRemoveStudent.addActionListener(this);
	adminAddStudentPanel.hButton.addActionListener(this);
	adminAddStudentPanel.bButton.addActionListener(this);
	adminAddStudentPanel.sButton.addActionListener(this);
	adminRemoveStudentPanel.bButton.addActionListener(this);
	adminRemoveStudentPanel.hButton.addActionListener(this);
	adminRemoveStudentPanel.sButton.addActionListener(this);
}

//updates the screen components when a student logs in
//updates the screen's components when a student logs in
public void updateStudentScreen(StudentController sController) {
	//updates each panel with the "controller's" info
	this.studentMenuPanel = new StudentMenuPanel();
	this.studentViewInfoPanel = new StudentViewInfoPanel(sController);

	//adds each updated panel to the card layout
	add(studentMenuPanel, "StudentMenu");
	add(studentViewInfoPanel, "StudentViewInfo");

	//adds a button listener for the student menu
	studentMenuPanel.cmdViewS.addActionListener(this);
	studentMenuPanel.cmdLogOut.addActionListener(this);
	studentViewInfoPanel.cmdHome.addActionListener(this);
}

//handles what should happen when the submit attendance button is clicked
public void submitAttendanceEvent() {
	int buttons = 0; //used to track if the radiobuttons have a selection
	//check if all boxes have a selection made
	for(int i = 0; i < groupList.size(); i++) {
	if(groupList.get(i).rButton1.isSelected() || groupList.get(i).rButton2.isSelected()) {
		buttons++;
	}
	}
	
	//if all of the boxes are filled, put the data in the database
	if(buttons == groupList.size()) {
	for(int i = 0; i < groupList.size(); i++) {
		//if the first button is selected, do this 
		if (groupList.get(i).rButton1.isSelected()) {
			aController.getData().markClassAttendance(aController.getModel(), true, i); //set the student's attendance as true
			groupList.get(i).bGroup.clearSelection(); //clear the button group
		}
		//if the second button is selected, do this
		else if(groupList.get(i).rButton2.isSelected()) {
			aController.getData().markClassAttendance(aController.getModel(), false, i); //set the student's attendance as false
			groupList.get(i).bGroup.clearSelection(); //clear the button group
		}
		}
	JOptionPane.showMessageDialog(null, "Attendance has been recorded.");
	}
	//if they are not filled, show this message to the user
	else {
		JOptionPane.showMessageDialog(null, "You must make a selection for every student.");
	}
}

//handles what should happen when the add student button is selected
public void addStudentEvent() {
	String gender = ""; //creates a gender variable as a string
	
	//check if the fields are all filled out correctly, i.e 5 digit PIN, gender selected, no spaces in any names
	if(!adminAddStudentPanel.userText.getText().contains(" ") && !adminAddStudentPanel.userText2.getText().contains(" ") 
			&& !adminAddStudentPanel.pinText.getText().contains(" ") &&adminAddStudentPanel.pinText.getText().length() == 5
			&& (adminAddStudentPanel.maleButton.isSelected() || adminAddStudentPanel.femaleButton.isSelected())) {

		//set gender as M or F
		if(adminAddStudentPanel.maleButton.isSelected()) {gender = "M";}
		else if(adminAddStudentPanel.femaleButton.isSelected()) {gender = "F";}
		
		//creates the student object and initialize their info
		Student s = new Student(adminAddStudentPanel.userText.getText(), adminAddStudentPanel.userText2.getText(), gender, 
				adminAddStudentPanel.pinText.getText(), 0, 0);
		
		aController.getData().addStudent(s, aController.administratorGetClassID()); //adds student to the database
		aController.administratorAddStudentToClass(s); //adds student to the arraylist of class members
		
		//clears the textboxes and buttons
		adminAddStudentPanel.userText.setText("");
		adminAddStudentPanel.userText2.setText("");
		adminAddStudentPanel.pinText.setText("");
		adminAddStudentPanel.femaleButton.setSelected(false);
		adminAddStudentPanel.maleButton.setSelected(false);
	}
	else {
		//output the message if conditions aren't met do this
		JOptionPane.showMessageDialog(null, "Please choose a gender and enter a valid first, last name, and PIN. \n"
				+ "Do not include any spaces when inputting information.");
	}
}

//performs some validation when the remove student button is selected
public void removeStudentEvent() {
	
	//checks if the text does not contain a space and is length 5
	if(!adminRemoveStudentPanel.pinText.getText().contains(" ") && adminRemoveStudentPanel.pinText.getText().length() == 5){
	aController.getData().removeStudent(adminRemoveStudentPanel.pinText.getText());//sends the PIN to the database function to remove the PIN
}
	//outputs the error message if the PIN is not valid
	else {JOptionPane.showMessageDialog(null, "Invalid PIN entered.");}
	adminRemoveStudentPanel.pinText.setText("");
}

//handles what should happen when the submit button is clicked
public void submitEvent() {
	String PIN = logInPanel.txtPIN.getText(); // sets the PIN as the text from the text box
	
	if(validateInteger(PIN) == true && PIN.length() == 5){//checks if the PIN is an integer and of length 5

	user = checkUserPIN(PIN, sData, aData); //validates that the user is in the database
	
	if(user == 'a') {
		aModel = aData.getAdminData(PIN); //inputs the admin data into a model 
	    aController = new AdministratorController(aModel, aView, aData); //creates a controller for the admin
	    aController.administratorGetStudentsInClass(); //inputs the students into the admin class
	    updateAdminScreen(aController); //updates the users information
	    cl.show(this, "AdminMenu"); //shows the admin menu
    }
	
	else if(user == 's') { 		
		sModel = sData.getStudentData(PIN);  //inputs the student data into a model 
	    sController = new StudentController(sModel, sView, sData); //creates a controller for the student
	    updateStudentScreen(sController); // updates the user's information
	    cl.show(this, "StudentMenu"); //shows the student menu
	}
	}
	
	else 
		JOptionPane.showMessageDialog(null, "You did not enter a 5-digit PIN, please try again");
	
	logInPanel.txtPIN.setText(""); //sets the textfield as empty
}
	
//checks a user's PIN for validation in the database, and returns a corresponding character value
public char checkUserPIN(String currentUserPIN, StudentActions sData, AdministratorActions aData) { 
		char user = 'n'; //default value for user
			if(aData.getAdminData(currentUserPIN).getPIN() != "null") { //checks if the entered user pin is in the Admin table 
				user = 'a'; //changes user to 'a' to indicate to the program that the user is an admin
				return user; //returns the updated user variable
		}
			else if(sData.getStudentData(currentUserPIN).getPIN() != "null") { //checks if the entered user pin is in Student table
				user = 's'; //changes user to 's' to indicate to the program that the user is an student
				return user; //returns the updated user variable
		}
			else { //the else statement returns the same user variable back to the program because the pin was not found in the database
				JOptionPane.showMessageDialog(null, "The PIN is invalid");
				return user;
		}
	}
	
//validates that the PIN is an integer
public boolean validateInteger(String userInput) {
			boolean isInt;
					     
			try {
				Integer input = Integer.parseInt(userInput);
				isInt = true;
			}
			catch (Exception e){
				isInt = false;
			}
			return isInt;
}

}

