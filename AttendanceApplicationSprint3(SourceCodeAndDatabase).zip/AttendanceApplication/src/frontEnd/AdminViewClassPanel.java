package frontEnd;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import backEnd.AdministratorController;

public class AdminViewClassPanel extends JPanel{
	JButton cmdHome;
	JLabel lblHeader;
	
	//default constructor
	AdminViewClassPanel(){}
	
	//overloaded constructor 
	AdminViewClassPanel(AdministratorController aController){
	String[] headerArray = {"Name", "PIN", "Gender", "Days Present", "Days Absent"}; 
	String[][] classData = new String[aController.administratorGetClassList().size()][5];
	JTable infoTable;
	
	//creates a header label
	lblHeader = new JLabel ("                    Class Attendance");
	lblHeader.setPreferredSize(new Dimension(475,100));
	lblHeader.setFont(new Font("Serif", Font.BOLD, 28));
	
	//creates a home button
	cmdHome = new JButton("Home");
	cmdHome.setPreferredSize(new Dimension(250,50));
	cmdHome.setFont(new Font("Serif", Font.BOLD, 32));

	
	for(int i = 0; i < aController.administratorGetClassList().size(); i++) {
		
			Integer intDaysAttended = (Integer) aController.administratorGetClassList().get(i).getDaysAttended();//type casts the int to Integer
			String strDaysAttended = intDaysAttended.toString(); //converts the Integer to string
			Integer intDaysMissed = (Integer) aController.administratorGetClassList().get(i).getDaysMissed();//type casts the int to Integer
			String strDaysMissed = intDaysMissed.toString(); //converts the Integer to string
			
			classData[i][0] = aController.administratorGetClassList().get(i).getfName() + " "
					+  aController.administratorGetClassList().get(i).getlName(); //puts the student's name in the first spot of the array
			classData[i][1] = aController.administratorGetClassList().get(i).getPIN(); //puts the student's name in the second spot of the array
			classData[i][2] = aController.administratorGetClassList().get(i).getGender(); // puts the student's gender in the third spot of the array
			classData[i][3] = strDaysAttended; //puts the student's days attended in the fourth spot of the array
			classData[i][4] = strDaysMissed; //puts the student's days missed in the fourth spot of the array
	}
	
	//puts the info into the table and sets some characteristics for it
	infoTable = new JTable (classData, headerArray);
	infoTable.setBackground(Color.WHITE);
	infoTable.setPreferredSize(new Dimension(500, 300));
	infoTable.setDefaultEditor(Object.class, null);
	
	//sets the column widths
	for(int i = 0; i < 5; i++) {infoTable.getColumnModel().getColumn(i).setPreferredWidth(50);}
	
	//sets the column heights
	for(int i = 0; i < aController.administratorGetClassList().size(); i++) {infoTable.setRowHeight(infoTable.getRowHeight() + 3);}
	
	//puts the table into a scroll pane
	JScrollPane scrollPane = new JScrollPane(infoTable);
	scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS); 
	scrollPane.setPreferredSize(new Dimension(600, 325));
	scrollPane.setBackground(Color.WHITE);
	
	//adds the scroll pane to the center panel
	JPanel centerPanel = new JPanel();
	centerPanel.add(scrollPane);
	centerPanel.setBackground(Color.WHITE);
	
	//adds the home button to the bottom panel
	JPanel bottomPanel =  new JPanel();
	bottomPanel.setBackground(Color.white);
	bottomPanel.add(cmdHome);
	
	//adds the header label to the bottom panel
	JPanel topPanel = new JPanel();
	topPanel.setBackground(Color.white);
	topPanel.add(lblHeader);
	
	//sets info about the panel and adds the components to it
	setBackground(Color.WHITE);
	setLayout(new BorderLayout());
	add(centerPanel, BorderLayout.CENTER);
	add(bottomPanel, BorderLayout.SOUTH);
	add(topPanel, BorderLayout.NORTH);
	}
	
}
