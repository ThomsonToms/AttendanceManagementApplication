import java.sql.SQLException;
import java.util.Scanner;

/*
 * Filename:    AdministratorView.java
 * Package:     No package
 * Project:     Attendance Management System
 * Author:      Jacob Bianco, Comlan Acolitse, and Thomson Toms
 * Section:     IST 311
 * Assignment:  Sprint 1
 * Description: Contains output functions for an administrator
 * Date Created: 9/3/22
 * Date modified:10/6/22
 *
 */

public class AdministratorView
{
	
	
	//exit program prompt for an admin
    public static void exitProgram(Administrator model) {
        System.out.println(model.getUserfName() + ", thank you for using the Attendance Application to manage your student's grades.");
    }
    
    
    //Prints admin login info
    public static void printAdministratorInfo(Administrator model){
        System.out.println("Name: " + model.getUserfName() + " " + model.getUserlName());
        System.out.println("Gender: " + model.getUserGender());
        System.out.println("PIN Number: " + model.getUserPIN());
        System.out.println("Class ID number: " + model.getClassID() + "\n");
    }

    
    //iterates through an admin's class list and prints info about each student
    public static void printAdministratorClassInfo(Administrator model) {
    	for(int i = 0; i < model.getClassList().size(); i ++) {
    		StudentView.printStudentAttendance(model.getClassList().get(i)); //prints info about the specific student in the list
    	}
    }


  //displays the administrator menu for the main method
    public static void displayMenu(Administrator model, AdministratorActions aData) throws SQLException  {//number based menu system for admins
    		boolean run = true;
    		System.out.println("\nWelcome to your Attendance Application. Please choose one of the following options by typing in the corresponding number.");
    		
    		while(run) { //loops the menu while run is true
    			
    		System.out.println("1: Check class attendance.");
    		System.out.println("2: Mark class attendance.");
    		System.out.println("3: Add a student to your class.");
    		System.out.println("4: Remove a student from your class.");
    		System.out.println("5: View my profile's information.");
    		System.out.println("6: Exit the application.");
    		
    		Scanner sc = new Scanner(System.in);
    		int num = sc.nextInt(); //receives input for the menu option the admin chooses
    		
    		switch(num) {
    		case 1: 
    			printAdministratorClassInfo(model);//prints the admins class info
    			break;
    		case 2: 
    			aData.markClassAttendance(model);//allows the admin to mark the class's attendance
    			break;
    		case 3: 
    			aData.addStudent(getNewStudentInfo()); //calls add student method
    			break;
    		case 4:
    			aData.removeStudent(getDroppedStudentInfo()); //calls remove student method
    			break;
    		case 5: 
    			printAdministratorInfo(model); //prints info about the admin
    			break;
    		case 6: 
    			aData.closeConnection();;//closes the connection to the database
        	    exitProgram(model); //displays exit message for admin
    			run = false; //changes run to false if the user selects 6
    			break;
    			}	
    		}
    	}

  //retrieves info about a new student and returns it as a student object 
    public static Student getNewStudentInfo() {
  	Scanner sc = new Scanner(System.in);
  	System.out.println("Enter the student's first name.");
  	String fName = sc.nextLine();
  	System.out.println("Enter the student's last name.");
  	String lName = sc.nextLine();
  	System.out.println("Enter the M or F for the student's gender.");
  	String gender = sc.nextLine();
  	System.out.println("Create a 5 digit PIN for the student");
  	String PIN = sc.nextLine();
  	Student s = new Student(fName, lName, gender, PIN, 0, 0);
  	return s;
  }


//recieves a PIN as input from a user and returns it
    public static String getDroppedStudentInfo() {
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter the student's PIN who you want to remove from the system.");
	String PIN = sc.nextLine();
	return PIN;
}

}