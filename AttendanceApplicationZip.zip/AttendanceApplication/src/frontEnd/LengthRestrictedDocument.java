/*
 * Filename:    LengthRestrictedDocument.java
 * Package:     frontEnd
 * Project:     Attendance Management System
 * Author:      Jacob Bianco, Comlan Acolitse, and Thomson Toms
 * Section:     IST 311
 * Assignment:  Sprint 3
 * Description: This class contains the validation code to make sure an input is of a certain length. I got this class from stack overflow:
 * https://stackoverflow.com/questions/13075564/limiting-length-of-input-in-jtextfield-is-not-working
 * Date Created: 11/1/22
 * Date modified: 11/1/22
 * */
package frontEnd;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.PlainDocument;

public final class LengthRestrictedDocument extends PlainDocument {

	private static final long serialVersionUID = 1L;
	private final int limit;

	  public LengthRestrictedDocument(int limit) {
	    this.limit = limit;
	  }

	  @Override
	  public void insertString(int offs, String str, AttributeSet a)
	      throws BadLocationException {
	    if (str == null)
	      return;

	    if ((getLength() + str.length()) <= limit) {
	      super.insertString(offs, str, a);
	    }
	  }
	}
	