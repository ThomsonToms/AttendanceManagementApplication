/*
 * Filename:    MainFrame.java
 * Package:     frontEnd
 * Project:     Attendance Management System
 * Author:      Jacob Bianco, Comlan Acolitse, and Thomson Toms
 * Section:     IST 311
 * Assignment:  Sprint 3
 * Description: This class sets attributes about the frame for the program's GUI
 * Date Created: 11/1/22
 * Date modified: 11/1/22
 * */
package frontEnd;

import java.awt.Color;
import javax.swing.*;

public class MainFrame extends JFrame {
	//sets an icon for the frame
	final String icon = "C:/Users/jacob/eclipse-workspace/AttendanceApplication/aaimage.png";
	
	//sets the width and height of the frame
	final int WIDTH = 750;
	final int HEIGHT = 700;
	
	public MainFrame(){
		
		//sets information about the JFrame such as name, color, size, icon image and default close operation
		setTitle("Attendance Application");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setBackground(Color.WHITE);
		setSize(WIDTH, HEIGHT);
		setLocationRelativeTo(null);
		setIconImage(new ImageIcon(icon).getImage());
		
		//sets the "look and feel" of the frame
		try { 
		    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
		    e.printStackTrace();
		}
		//adds the container panel to the frame and sets the frame as visible
		add(new ContainerPanel());
		setVisible(true);
	}
}


	
	
	
