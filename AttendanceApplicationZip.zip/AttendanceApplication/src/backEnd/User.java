package backEnd;

/*
 * Filename:    User.java
 * Package:     No package
 * Project:     Attendance Management System
 * Author:      Jacob Bianco, Comlan Acolitse, and Thomson Toms
 * Section:     IST 311
 * Assignment:  Sprint 1
 * Description: The User class contains attributes and methods that all users should have
 * Date Created: 9/3/22
 * Date modified:9/8/22
 *
 */
public interface User {
	//all of the get and set methods that users should have
	public String getfName();
	public String getlName();
	public String getGender();
	public String getUserPIN();
	public void setfName();
	public void setlName();
	public void setGender();
	public void setPIN();
}

	 


